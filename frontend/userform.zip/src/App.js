import React from 'react';

import  Form  from './components/HomePage'; // Update the import statement



function App() {
  return (
    <div>
      {/* <h1>My App</h1> */}
      <Form/>
      
    </div>
  );
}

export default App;
