
import React, { useState } from 'react';
import axios from 'axios';
import './HomePage.css';

const Form = () => {
  const [firstName, setFirstName] = useState('');
  const [lastName, setLastName] = useState('');
  const [age, setAge] = useState('');
  const [email, setEmail] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [formData, setFormData] = useState([]); // State to store form data

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:3004/submitForm', {
        firstName,
        lastName,
        age,
        email,
        phoneNumber,
      });
      console.log('Form submitted:', response.data);
      alert('Form submitted', response.data);

      // Reset form fields
      setFirstName('');
      setLastName('');
      setAge('');
      setEmail('');
      setPhoneNumber('');
    } catch (error) {
      console.error('Error submitting form:', error);
    }
  };

  const handleShowAllData = async () => {
    try {
      // Fetch all form data from the server
      const response = await axios.get('http://localhost:3004/getFormData');
      setFormData(response.data.data);
    } catch (error) {
      console.error('Error fetching form data:', error);
    }
  };

  // useEffect(() => {
  //   // Fetch data when the component mounts
  //   handleShowAllData();
  // }, []); // Empty dependency array ensures the effect runs only once when mounted

  return (
    <div className="formcontainer">
      <form onSubmit={handleSubmit} className="booking-form" method="POST">
      <label className="form-group">
           First Name:
   <input type="text" value={firstName} onChange={(e) => setFirstName(e.target.value)} />
        </label>
        <br />
        <label className="form-group">
           Last Name:
           <input type="text" value={lastName} onChange={(e) => setLastName(e.target.value)} />
        </label>
        <br />
        <label className="form-group">
          Age:
          <input type="text" value={age} onChange={(e) => setAge(e.target.value)} />
        </label>
       <br />
        <label className="form-group">
         Email:
          <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        </label>
        <br />
         <label className="form-group">
         Phone Number:
           <input type="text" value={phoneNumber} onChange={(e) => setPhoneNumber(e.target.value)} />
        </label>
        <br />
        <button className="formbtn" type="submit">
          Save
        </button>
      </form>
      <button className="formbtn1" onClick={handleShowAllData}>
        Show All Data
      </button>

      {/* Display form data in a table */}
      {formData.length > 0 && (
        <div className="table-container">
          <h2>Form Data</h2>
          <table>
            <thead>
              <tr>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Age</th>
                <th>Email</th>
                <th>Phone Number</th>
              </tr>
            </thead>
            <tbody>
              {formData.map((data) => (
                <tr key={data._id}>
                  <td>{data.firstName}</td>
                  <td>{data.lastName}</td>
                  <td>{data.age}</td>
                  <td>{data.email}</td>
                  <td>{data.phoneNumber}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};

export default Form;






































// import React, { useState } from 'react';
// import axios from 'axios';
// import './HomePage.css';

// const Form = () => {
//   const [firstName, setFirstName] = useState('');
//   const [lastName, setLastName] = useState('');
//   const [age, setAge] = useState('');
//   const [email, setEmail] = useState('');
//   const [phoneNumber, setPhoneNumber] = useState('');

  



// const handleSubmit = async (e) => {
//     e.preventDefault();
//     try {
//       const response = await axios.post('http://localhost:3001/submitForm', {
//         firstName,
//         lastName,
//         age,
//         email,
//         phoneNumber,
//       });
//       console.log('Form submitted:', response.data);
//       alert('Form submitted', response.data);
  
//       // Reset form fields
//       setFirstName('');
//       setLastName('');
//       setAge('');
//       setEmail('');
//       setPhoneNumber('');
//     } catch (error) {
//       console.error('Error submitting form:', error);
//     }
//   };
  

  

//   return (
//     <div className="formcontainer">
//       <form onSubmit={handleSubmit} className="booking-form" method="POST">
//         <h2>Book a Room</h2>
//         <p>Fill out the form below to book your room.</p>
//         <label className="form-group">
//           First Name:
//           <input type="text" value={firstName} onChange={(e) => setFirstName(e.target.value)} />
//         </label>
//         <br />
//         <label className="form-group">
//           Last Name:
//           <input type="text" value={lastName} onChange={(e) => setLastName(e.target.value)} />
//         </label>
//         <br />
//         <label className="form-group">
//           Age:
//           <input type="number" value={age} onChange={(e) => setAge(e.target.value)} />
//         </label>
//         <br />
//         <label className="form-group">
//           Email:
//           <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
//         </label>
//         <br />
//         <label className="form-group">
//           Phone Number:
//           <input type="number" value={phoneNumber} onChange={(e) => setPhoneNumber(e.target.value)} />
//         </label>
//         <br />
//         {/* Other form fields remain the same */}
//         <button className="formbtn" type="submit">
//           Save
//         </button>
//       </form> 
//       <button className="formbtn1">Show All Data</button>
//     </div> 

    
//   );
// };

// export default Form;











































// import React, { useState, useEffect } from 'react';
// import axios from 'axios';
// import './HomePage.css';

//  const Form = () => {
//   const [firstName, setFirstName] = useState('');
//   const [lastName, setLastName] = useState('');
//   const [age, setAge] = useState('');
//   const [email, setEmail] = useState('');
//   const [phoneNumber, setPhoneNumber] = useState('');

  



// const handleSubmit = async (e) => {
//     e.preventDefault();
//     try {
//       const response = await axios.post('http://localhost:3001/submitForm', {
//         firstName,
//         lastName,
//         age,
//         email,
//         phoneNumber,
//       });
//       console.log('Form submitted:', response.data);
//       alert('Form submitted', response.data);
  
//       // Reset form fields
//       setFirstName('');
//       setLastName('');
//       setAge('');
//       setEmail('');
//       setPhoneNumber('');
//     } catch (error) {
//       console.error('Error submitting form:', error);
//     }
//   };
  

  

//   return (
//     <div className="formcontainer">
//       <form onSubmit={handleSubmit} className="booking-form" method="POST">
//         <label className="form-group">
//           First Name:
//           <input type="text" value={firstName} onChange={(e) => setFirstName(e.target.value)} />
//         </label>
//         <br />
//         <label className="form-group">
//           Last Name:
//           <input type="text" value={lastName} onChange={(e) => setLastName(e.target.value)} />
//         </label>
//         <br />
//         <label className="form-group">
//           Age:
//           <input type="number" value={age} onChange={(e) => setAge(e.target.value)} />
//         </label>
//         <br />
//         <label className="form-group">
//           Email:
//           <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} />
//         </label>
//         <br />
//         <label className="form-group">
//           Phone Number:
//           <input type="number" value={phoneNumber} onChange={(e) => setPhoneNumber(e.target.value)} />
//         </label>
//         <br />
//         {/* Other form fields remain the same */}
//         <button className="formbtn" type="submit">
//           Save
//         </button>
//       </form>
      
//     </div> 

    
//   );
// };  

// export default Form;